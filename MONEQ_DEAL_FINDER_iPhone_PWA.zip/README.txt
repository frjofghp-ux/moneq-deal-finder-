MONEQ DEAL FINDER - iPhone PWA package

포함 파일
- index.html: 웹앱
- manifest.webmanifest: 홈 화면 설치 설정
- sw.js: 기본 오프라인 캐시
- icon-192.png / icon-512.png: 앱 아이콘

설치하려면 반드시 HTTPS 주소로 배포해야 합니다.
ZIP 자체를 아이폰에 설치하는 앱(IPA)은 아닙니다.

GitHub Pages 배포
1. GitHub 저장소를 만들고 Public으로 설정
2. ZIP 압축을 푼 뒤 파일 5개를 저장소 최상위(root)에 업로드
3. Settings > Pages > Deploy from a branch > main > /(root) > Save
4. 생성된 https://계정명.github.io/저장소명/ 주소를 iPhone Safari에서 열기
5. 공유 버튼 > 홈 화면에 추가

현재 앱은 매물 직접 등록, 예상 차익 계산, 조건 저장 및 플랫폼 검색 링크 열기를 지원합니다.
당근/번개장터의 자동 매물 수집은 공식 허용 API/파트너 권한과 연동이 필요하며, 이 패키지에는 포함되어 있지 않습니다.
브라우저 알림은 iOS 버전·홈 화면 설치·권한 및 알림 구현 조건에 영향을 받습니다. 서버 푸시 알림은 별도 서버 구성이 필요합니다.
